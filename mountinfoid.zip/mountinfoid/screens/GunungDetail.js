import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

const GunungDetail = ({ route }) => {
  const { gunung } = route.params;

  return (
    <View style={styles.container}>
      <Image source={{ uri: gunung.photo }} style={styles.photo} />
      <Text style={styles.title}>{gunung.name}</Text>
      <Text style={styles.subtitle}>{gunung.location}</Text>
      <Text style={styles.text}>{gunung.height}</Text>
      <Text style={styles.text}>{gunung.description}</Text>
      {gunung.trails.map((trail) => (
        <View key={trail.id}>
          <Text style={styles.trailTitle}>{trail.name}</Text>
          <Text style={styles.trailText}>{trail.length}</Text>
          <Text style={styles.trailText}>{trail.difficulty}</Text>
          <Text style={styles.trailText}>{trail.description}</Text>
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  photo: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  text: {
    fontSize: 16,
    marginBottom: 5,
  },
  trailTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  trailText: {
    fontSize: 16,
    marginBottom: 5,
  },
});

export default GunungDetail;