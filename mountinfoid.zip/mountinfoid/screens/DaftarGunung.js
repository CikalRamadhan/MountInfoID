import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ImageBackground, LogBox } from 'react-native';

const DaftarGunung = ({ navigation }) => {
  const [dataGunung, setDataGunung] = useState([
  { id: 1, name: 'Gunung Merapi', height: '2.930 mdpl', location: 'Jawa Tengah' },
  { id: 2, name: 'Gunung Semeru', height: '3.676 mdpl', location: 'Jawa Timur' },
  { id: 3, name: 'Gunung Sindoro', height: '3.153 mdpl', location: 'Jawa Tengah' },
  { id: 4, name: 'Gunung Sumbing', height: '3.371 mdpl', location: 'Jawa Tengah' },
  { id: 5, name: 'Gunung Telomoyo', height: '1.894 mdpl', location: 'Jawa Tengah' },
  { id: 6, name: 'Gunung Ayamayam', height: '1.022 mdpl', location: 'Jawa Tengah' },
  { id: 7, name: 'Gunung Bismo', height: '2.365 mdpl', location: 'Jawa Tengah' },
  { id: 8, name: 'Gunung Lawu', height: '3.265 mdpl', location: 'Jawa Tengah' },
  { id: 9, name: 'Gunung Blego', height: '1.022 mdpl', location: 'Jawa Tengah' },
  { id: 10, name: 'Gunung Lasem', height: '1.022 mdpl', location: 'Jawa Tengah' },
  { id: 11, name: 'Gunung Tidar', height: '503 mdpl', location: 'Jawa Tengah' },
  { id: 12, name: 'Gunung Ungaran', height: '2.050 mdpl', location: 'Jawa Tengah' },
  { id: 13, name: 'Gunung Lawu', height: '3.265 mdpl', location: 'Jawa Timur' },
  { id: 14, name: 'Gunung Bromo', height: '2.329 mdpl', location: 'Jawa Timur' },
  { id: 15, name: 'Gunung Panderman', height: '2.045 mdpl', location: 'Jawa Timur' },
  { id: 16, name: 'Gunung Kawi', height: '2.551 mdpl', location: 'Jawa Timur' },
  { id: 17, name: 'Gunung Ijen', height: '2.386 mdpl', location: 'Jawa Timur' },
  { id: 18, name: 'Gunung Kelud', height: '1.731 mdpl', location: 'Jawa Timur' },
  { id: 19, name: 'Gunung Argorupo', height: '3.088 mdpl', location: 'Jawa Timur' },
  { id: 20, name: 'Gunung Arjuno', height: '3.339 mdpl', location: 'Jawa Timur' },
  { id: 21, name: 'Gunung Baluran', height: '1.247 mdpl', location: 'Jawa Timur' },
  { id: 22, name: 'Gunung Batok', height: '2.440 mdpl', location: 'Jawa Timur' },
  { id: 23, name: 'Gunung Anjasmoro', height: '2.282 mdpl', location: 'Jawa Timur' },
  { id: 24, name: 'Gunung Blokorobrubuh', height: '2.230 mdpl', location: 'Jawa Timur' },
  { id: 25, name: 'Gunung Butak', height: '2.868 mdpl', location: 'Jawa Timur' },
  { id: 26, name: 'Gunung Liman', height: '2.563 mdpl', location: 'Jawa Timur' },
  { id: 27, name: 'Gunung Pandan', height: '903 mdpl', location: 'Jawa Timur' },
  { id: 28, name: 'Gunung Penanggunan', height: '1.653 mdpl', location: 'Jawa Timur' },
  { id: 29, name: 'Gunung Berungkal', height: '1.040 mdpl', location: 'Jawa Timur' },
  { id: 30, name: 'Gunung Penanjakan', height: '2.329 mdpl', location: 'Jawa Timur' },
  { id: 31, name: 'Gunung Ranti', height: '2.601 mdpl', location: 'Jawa Timur' },
  { id: 32, name: 'Gunung Suket', height: '2.950 mdpl', location: 'Jawa Timur' },
  { id: 33, name: 'Gunung Argowayang', height: '2.162 mdpl', location: 'Jawa Timur' },
  { id: 34, name: 'Gunung Welirang', height: '3.156 mdpl', location: 'Jawa Timur' },
  { id: 35, name: 'Gunung Wilis', height: '2.563 mdpl', location: 'Jawa Timur' },
  { id: 36, name: 'Gunung Biser', height: '1.359 mdpl', location: 'Jawa Timur' },
  { id: 37, name: 'Gunung Betiri', height: '1.233 mdpl', location: 'Jawa Timur' },
  { id: 38, name: 'Gunung Raung', height: '3.244 mdpl', location: 'Jawa Timur' },
  { id: 39, name: 'Gunung Galunggung', height: '1.820 mdpl', location: 'Jawa Barat' },
  { id: 40, name: 'Gunung Pangrango', height: '3.019 mdpl', location: 'Jawa Barat' },
  { id: 41, name: 'Gunung Papandayan', height: '2.655 mdpl', location: 'Jawa Barat' },
  { id: 42, name: 'Gunung Salak', height: '1.648 mdpl', location: 'Jawa Barat' },
  { id: 43, name: 'Gunung Tampomas', height: '1.684 mdpl', location: 'Jawa Barat' },
  { id: 44, name: 'Gunung Tangkuban Parahu', height: '2.084 mdpl', location: 'Jawa Barat' },
  { id: 45, name: 'Gunung Ciremai', height: '3.074 mdpl', location: 'Jawa Barat' },
  { id: 46, name: 'Gunung Cikuray', height: '2.821 mdpl', location: 'Jawa Barat' },
  { id: 47, name: 'Gunung Guntur', height: '2.249 mdpl', location: 'Jawa Barat' },
  { id: 48, name: 'Gunung Halimun', height: '1.929 mdpl', location: 'Jawa Barat' },
  { id: 49, name: 'Gunung Malabar', height: '2.343 mdpl', location: 'Jawa Barat' },
  { id: 50, name: 'Gunung Tilu', height: '1.076 mdpl', location: 'Jawa Barat' },
  { id: 51, name: 'Gunung Wayang', height: '2.182 mdpl', location: 'Jawa Barat' },
  { id: 52, name: 'Gunung Bongkok', height: '1.141 mdpl', location: 'Jawa Barat' },
  { id: 53, name: 'Gunung Bukit Tunggul', height: '2.209 mdpl', location: 'Jawa Barat' },
  { id: 54, name: 'Gunung Burangrang', height: '2.821 mdpl', location: 'Jawa Barat' },
  { id: 55, name: 'Gunung Kancana', height: '2.050 mdpl', location: 'Jawa Barat' },
  { id: 56, name: 'Gunung Manglayang', height: '1.210 mdpl', location: 'Jawa Barat' },
  { id: 57, name: 'Gunung Munara', height: '367 mdpl', location: 'Jawa Barat' },
  { id: 58, name: 'Gunung Patuha', height: '2.434 mdpl', location: 'Jawa Barat' },
  { id: 59, name: 'Gunung Sanggabuana', height: '1.291 mdpl', location: 'Jawa Barat' },
  { id: 60, name: 'Gunung Cakrabuana', height: '1.721 mdpl', location: 'Jawa Barat' },
  { id: 61, name: 'Gunung Subang', height: '1.206 mdpl', location: 'Jawa Barat' },
  { id: 62, name: 'Talaga Bodas', height: '2.201 mdpl', location: 'Jawa Barat' }

    // add more data here
  ]);

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.itemContainer}
      onPress={() => navigation.navigate('GunungDetail', { gunung: item })}
    >
      <Text style={styles.itemName}>{item.name}</Text>
      <Text style={styles.itemLocation}>{item.location}</Text>
      <Text style={styles.itemHeight}>{item.height}</Text>
    </TouchableOpacity>
  );

  return (
    <ImageBackground
      source={require('../assets/background_image.jpg')}
      style={styles.backgroundImage}
    >
      <View style={styles.container}>
        <Text style={styles.title}>Daftar Gunung</Text>
        <FlatList
          data={dataGunung}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          onScroll={(event) => {
            console.log('onScroll', event.nativeEvent.contentOffset.y);
          }}
          onContentSizeChange={(contentWidth, contentHeight) => {
            console.log('contentSize', { contentWidth, contentHeight });
          }}
          onLayout={(event) => {
            console.log('layoutMeasurement', event.nativeEvent.layout);
          }}
        />
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  itemContainer: {
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
  },
  itemName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  itemLocation: {
    fontSize: 16,
  },
  itemHeight: {
    fontSize: 14,
    fontStyle: 'italic',
  },
});

export default DaftarGunung;