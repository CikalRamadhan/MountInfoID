import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import Home from './screens/Home';
import DaftarGunung from './screens/DaftarGunung';
import GunungDetail from './screens/GunungDetail';

const Stack = createStackNavigator();

const Navigation = () => {
  return (
    <Stack.Navigator initialRouteName="Home">
      <Stack.Screen name="Home" component={Home} options={{ title: 'InfoGunungID' }} />
      <Stack.Screen name="DaftarGunung" component={DaftarGunung} options={{ title: 'Daftar Gunung' }} />
      <Stack.Screen name="GunungDetail" component={GunungDetail} options={{ title: 'Detail Gunung' }} />
    </Stack.Navigator>
  );
};

export default Navigation;
